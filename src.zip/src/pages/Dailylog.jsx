import React from "react";

export default function DailyLog() {
  return (
    <div className="page-card">
      <h1>📝 Daily Log</h1>
    </div>
  );
}