import React from "react";

export default function Analytics() {
  return (
    <div className="page-card">
      <h1>📊 Analytics</h1>
    </div>
  );
}