import React from "react";
import { SUBJECTS, COMPLETED_SUBJECTS } from "../data/subjects";

export default function Dashboard() {
  const remainingLectures = SUBJECTS.reduce(
    (sum, subject) => sum + subject.totalLectures,
    0
  );

  const remainingHours = SUBJECTS.reduce(
    (sum, subject) =>
      sum + subject.totalLectures * subject.hoursPerLecture,
    0
  );

  const targetDate = new Date("2026-07-31");
  const today = new Date();

  const daysLeft = Math.max(
    0,
    Math.ceil((targetDate - today) / (1000 * 60 * 60 * 24))
  );

  const requiredPace = (remainingLectures / daysLeft).toFixed(1);

  return (
    <>
      <div className="page-card">
        <h1>⚡ CA Inter Command Center</h1>
        <p>
          July 31 Completion Target
        </p>
      </div>

      <div className="stats-grid">

        <div className="stat-card">
          <h3>📚 Remaining Lectures</h3>
          <h1>{remainingLectures}</h1>
        </div>

        <div className="stat-card">
          <h3>⏱ Remaining Hours</h3>
          <h1>{remainingHours.toFixed(0)}</h1>
        </div>

        <div className="stat-card">
          <h3>📅 Days Left</h3>
          <h1>{daysLeft}</h1>
        </div>

        <div className="stat-card">
          <h3>🚀 Required Pace</h3>
          <h1>{requiredPace}/day</h1>
        </div>

      </div>

      <div className="page-card">
        <h2>✅ Completed Subjects</h2>

        {COMPLETED_SUBJECTS.map((subject) => (
          <div
            key={subject.id}
            style={{
              padding: "12px",
              marginTop: "10px",
              borderRadius: "10px",
              background: "#10253a",
            }}
          >
            {subject.name} ({subject.totalLectures} lectures)
          </div>
        ))}
      </div>

      <div className="page-card">
        <h2>📖 Pending Subjects</h2>

        {SUBJECTS.map((subject) => (
          <div
            key={subject.id}
            style={{
              marginTop: "15px",
              padding: "12px",
              borderRadius: "12px",
              background: "#10253a",
            }}
          >
            <b>{subject.name}</b>

            <div>
              Lectures: {subject.totalLectures}
            </div>

            <div>
              Hours:{" "}
              {(
                subject.totalLectures *
                subject.hoursPerLecture
              ).toFixed(1)}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}