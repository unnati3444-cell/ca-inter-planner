import React from "react";

export default function Settings() {
  return (
    <div className="page-card">
      <h1>⚙️ Settings</h1>
    </div>
  );
}