import React from "react";

export default function Simulator() {
  return (
    <div className="page-card">
      <h1>🎯 Simulator</h1>
    </div>
  );
}