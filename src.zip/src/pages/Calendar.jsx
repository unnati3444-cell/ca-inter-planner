import React from "react";

export default function Calendar() {
  return (
    <div className="page-card">
      <h1>📅 Calendar</h1>
    </div>
  );
}