import React, { useState } from "react";

import Sidebar from "./components/Sidebar";

import Dashboard from "./pages/Dashboard";
import Calendar from "./pages/Calendar";
import DailyLog from "./pages/DailyLog";
import Analytics from "./pages/Analytics";
import Simulator from "./pages/Simulator";
import Settings from "./pages/Settings";

import "./styles/app.css";

export default function App() {
  const [activePage, setActivePage] = useState("dashboard");

  const renderPage = () => {
    switch (activePage) {
      case "dashboard":
        return <Dashboard />;

      case "calendar":
        return <Calendar />;

      case "dailylog":
        return <DailyLog />;

      case "analytics":
        return <Analytics />;

      case "simulator":
        return <Simulator />;

      case "settings":
        return <Settings />;

      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="app-layout">
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
      />

      <main className="main-content">
        {renderPage()}
      </main>
    </div>
  );
}